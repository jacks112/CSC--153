﻿/**
 * 2/14/2018
 * CSC 153
 * Byron Jackson, Jr.
 * Progam display name in 6 different formatts
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Name_Formatter
{
    public partial class Nameformatter : Form
    {
        public Nameformatter()
        {
            InitializeComponent();
        }

        //Declare variables
        string fn = "";
        string mn = "";
        string ln = "";
        string t = "";


        private void formattbutton1_Click(object sender, EventArgs e)
        {
            //Display Name Title, First, Middle, & Last
            fn = firstNameBox.Text;
            mn = middleNameBox.Text;
            ln = lastNameBox.Text;
            t = titleBox.Text;

            displayLabelBox.Text = t + " " +fn + " " +mn + " " + ln;
        
        } 

        private void formattButton2_Click(object sender, EventArgs e)
        {
            //Display First, Middle, & Last
            displayLabelBox.Text = fn + " " + mn + " " + ln;
        }

        private void formattButton3_Click(object sender, EventArgs e)
        {
            //Display First & Last
            displayLabelBox.Text = fn + " " + ln;
            
        }

        private void formattButton4_Click(object sender, EventArgs e)
        {
            //Display Last, First, Middle, & Title
            displayLabelBox.Text = ln + " " + fn + " " + mn + " " + t;
        }

        private void formattButton5_Click(object sender, EventArgs e)
        {
          //Display Last, First, & Middle
          displayLabelBox.Text = ln + " " +fn + " " + mn;
        }

        private void formattButton6_Click(object sender, EventArgs e)
        {
            //Display Last & First
            displayLabelBox.Text = ln + " " + fn; 
        }
    }
}
