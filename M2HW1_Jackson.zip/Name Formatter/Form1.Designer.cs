﻿namespace Name_Formatter
{
    partial class Nameformatter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.middleNameBox = new System.Windows.Forms.TextBox();
            this.lastNameBox = new System.Windows.Forms.TextBox();
            this.titleBox = new System.Windows.Forms.TextBox();
            this.firstNameBox = new System.Windows.Forms.TextBox();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.formattbutton1 = new System.Windows.Forms.Button();
            this.formattButton2 = new System.Windows.Forms.Button();
            this.formattButton3 = new System.Windows.Forms.Button();
            this.formattButton4 = new System.Windows.Forms.Button();
            this.formattButton5 = new System.Windows.Forms.Button();
            this.formattButton6 = new System.Windows.Forms.Button();
            this.displayLabelBox = new System.Windows.Forms.Label();
            this.displayLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // middleNameBox
            // 
            this.middleNameBox.Location = new System.Drawing.Point(358, 67);
            this.middleNameBox.Name = "middleNameBox";
            this.middleNameBox.Size = new System.Drawing.Size(100, 20);
            this.middleNameBox.TabIndex = 0;
            // 
            // lastNameBox
            // 
            this.lastNameBox.Location = new System.Drawing.Point(358, 105);
            this.lastNameBox.Name = "lastNameBox";
            this.lastNameBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameBox.TabIndex = 1;
            // 
            // titleBox
            // 
            this.titleBox.Location = new System.Drawing.Point(358, 145);
            this.titleBox.Name = "titleBox";
            this.titleBox.Size = new System.Drawing.Size(100, 20);
            this.titleBox.TabIndex = 2;
            // 
            // firstNameBox
            // 
            this.firstNameBox.Location = new System.Drawing.Point(358, 31);
            this.firstNameBox.Name = "firstNameBox";
            this.firstNameBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameBox.TabIndex = 3;
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(249, 37);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(57, 13);
            this.firstNameLabel.TabIndex = 4;
            this.firstNameLabel.Text = "First Name";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(249, 74);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(69, 13);
            this.middleNameLabel.TabIndex = 5;
            this.middleNameLabel.Text = "Middle Name";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(252, 111);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(58, 13);
            this.lastNameLabel.TabIndex = 6;
            this.lastNameLabel.Text = "Last Name";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(193, 152);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(141, 13);
            this.titleLabel.TabIndex = 7;
            this.titleLabel.Text = "Title (Mr., Mrs., Ms., Dr., etc)";
            // 
            // formattbutton1
            // 
            this.formattbutton1.Location = new System.Drawing.Point(12, 195);
            this.formattbutton1.Name = "formattbutton1";
            this.formattbutton1.Size = new System.Drawing.Size(75, 23);
            this.formattbutton1.TabIndex = 8;
            this.formattbutton1.Text = "Formatt1";
            this.formattbutton1.UseVisualStyleBackColor = true;
            this.formattbutton1.Click += new System.EventHandler(this.formattbutton1_Click);
            // 
            // formattButton2
            // 
            this.formattButton2.Location = new System.Drawing.Point(93, 195);
            this.formattButton2.Name = "formattButton2";
            this.formattButton2.Size = new System.Drawing.Size(75, 23);
            this.formattButton2.TabIndex = 9;
            this.formattButton2.Text = "Formatt2";
            this.formattButton2.UseVisualStyleBackColor = true;
            this.formattButton2.Click += new System.EventHandler(this.formattButton2_Click);
            // 
            // formattButton3
            // 
            this.formattButton3.Location = new System.Drawing.Point(174, 195);
            this.formattButton3.Name = "formattButton3";
            this.formattButton3.Size = new System.Drawing.Size(75, 23);
            this.formattButton3.TabIndex = 10;
            this.formattButton3.Text = "Formatt3";
            this.formattButton3.UseVisualStyleBackColor = true;
            this.formattButton3.Click += new System.EventHandler(this.formattButton3_Click);
            // 
            // formattButton4
            // 
            this.formattButton4.Location = new System.Drawing.Point(12, 236);
            this.formattButton4.Name = "formattButton4";
            this.formattButton4.Size = new System.Drawing.Size(75, 23);
            this.formattButton4.TabIndex = 11;
            this.formattButton4.Text = "Formatt4";
            this.formattButton4.UseVisualStyleBackColor = true;
            this.formattButton4.Click += new System.EventHandler(this.formattButton4_Click);
            // 
            // formattButton5
            // 
            this.formattButton5.Location = new System.Drawing.Point(93, 236);
            this.formattButton5.Name = "formattButton5";
            this.formattButton5.Size = new System.Drawing.Size(75, 23);
            this.formattButton5.TabIndex = 12;
            this.formattButton5.Text = "Formatt5";
            this.formattButton5.UseVisualStyleBackColor = true;
            this.formattButton5.Click += new System.EventHandler(this.formattButton5_Click);
            // 
            // formattButton6
            // 
            this.formattButton6.Location = new System.Drawing.Point(174, 236);
            this.formattButton6.Name = "formattButton6";
            this.formattButton6.Size = new System.Drawing.Size(75, 23);
            this.formattButton6.TabIndex = 13;
            this.formattButton6.Text = "Formatt6";
            this.formattButton6.UseVisualStyleBackColor = true;
            this.formattButton6.Click += new System.EventHandler(this.formattButton6_Click);
            // 
            // displayLabelBox
            // 
            this.displayLabelBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.displayLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayLabelBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayLabelBox.Location = new System.Drawing.Point(275, 205);
            this.displayLabelBox.Name = "displayLabelBox";
            this.displayLabelBox.Size = new System.Drawing.Size(399, 54);
            this.displayLabelBox.TabIndex = 14;
            this.displayLabelBox.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // displayLabel
            // 
            this.displayLabel.AutoSize = true;
            this.displayLabel.Location = new System.Drawing.Point(50, 179);
            this.displayLabel.Name = "displayLabel";
            this.displayLabel.Size = new System.Drawing.Size(118, 13);
            this.displayLabel.TabIndex = 15;
            this.displayLabel.Text = "Choose Display Formatt";
            // 
            // Nameformatter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(686, 359);
            this.Controls.Add(this.displayLabel);
            this.Controls.Add(this.displayLabelBox);
            this.Controls.Add(this.formattButton6);
            this.Controls.Add(this.formattButton5);
            this.Controls.Add(this.formattButton4);
            this.Controls.Add(this.formattButton3);
            this.Controls.Add(this.formattButton2);
            this.Controls.Add(this.formattbutton1);
            this.Controls.Add(this.titleLabel);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.middleNameLabel);
            this.Controls.Add(this.firstNameLabel);
            this.Controls.Add(this.firstNameBox);
            this.Controls.Add(this.titleBox);
            this.Controls.Add(this.lastNameBox);
            this.Controls.Add(this.middleNameBox);
            this.Name = "Nameformatter";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox middleNameBox;
        private System.Windows.Forms.TextBox lastNameBox;
        private System.Windows.Forms.TextBox titleBox;
        private System.Windows.Forms.TextBox firstNameBox;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Button formattbutton1;
        private System.Windows.Forms.Button formattButton2;
        private System.Windows.Forms.Button formattButton3;
        private System.Windows.Forms.Button formattButton4;
        private System.Windows.Forms.Button formattButton5;
        private System.Windows.Forms.Button formattButton6;
        private System.Windows.Forms.Label displayLabelBox;
        private System.Windows.Forms.Label displayLabel;
    }
}

