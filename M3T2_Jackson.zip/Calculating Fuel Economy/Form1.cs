﻿/*
 * 2/21/2018
 * CSC153
 * Byron Jackson,Jr.
 * Program calculates fuel with if else statemets
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculating_Fuel_Economy
{
    public partial class CalculateFuelEconomy : Form
    {
        public CalculateFuelEconomy()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            //Variables
            double miles;       //hold miles
            double gallons;     //hold gallons
            double mpg;         //hold MPG
          
            //Validate the gallons text box control
            if(double.TryParse(gallonsTextBox.Text, out gallons))
            {
                // Validate miles text box
                if(double.TryParse(milesTextBox.Text, out miles))
                 {
                    //calculae MPG
                    mpg = miles / gallons;

                    //Display MPG in mpgLabel
                    mpgLabel.Text = mpg.ToString("n1");
                  }
                else
                  {
                    //Display error message for miles text box
                    MessageBox.Show("Invalid input for miles.");
                  }
                }
            else
            {
                // Dislplay error mesage for gallons text box
                MessageBox.Show("Invalid input for gallons");
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close form
            this.Close();
        }

        
    }
}
