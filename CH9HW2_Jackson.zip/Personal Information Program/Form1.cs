﻿/*
 * 5/07/2018    
 * CSC 153
 * Byron Jackson,Jr.
 * Program demostrate 3 classes to get persons info
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Personal_Information_Program
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<Person> personList = new List<Person>();

        //Get Person data
        private void GetUserData(Person person)
        {
            //Get user name
            person.Name = userNameTextBox.Text;

            //Get user address
            person.Address = userAddTextBox.Text;

            //Get user age
            if (int.TryParse(userAgeTextBox.Text, out int age))
            {
                person.Age = age;
            }
            else
            {
                //Error message
                MessageBox.Show("Please type in a number for age.");
            }

            //Get PhoneNumber
            if(double.TryParse(userPhoneNumTextBox.Text, out double phoneNumber))
            {
                person.PhoneNumber = phoneNumber;
            }
            else
            {
                //Error Message
                MessageBox.Show("Please enter your phone number for user.");
            }

        }

        private void GetMem1Data(Person member1)
        {
            //Get family member name
            member1.Name = mem1NameTextBox.Text;

            //Get family member address
            member1.Address = mem1AddTextBox.Text;

            //Get family member age
            if(int.TryParse(mem1AgeTextBox.Text, out int age))
            {
                member1.Age = age;
            }
            else
            {
                //Error Message
                MessageBox.Show("Please type in numbers for family member1 age.");
            }

            //Get Phone Number
            if(double.TryParse(mem1PhoNumTextBox.Text, out double phoneNumber))
            {
                member1.PhoneNumber = phoneNumber;
            }
            else
            {
                //Error message
                MessageBox.Show("Please type numbers for family member 1 phone number.");
            }
        }

        private void GetMem2Data(Person member2)
        {
            //Get family member name
            member2.Name = mem2NameTextBox.Text;

            //Get family member address
            member2.Address = mem2AddTextBox.Text;

            //Get family member age
            if (int.TryParse(mem1AgeTextBox.Text, out int age))
            {
                member2.Age = age;
            }
            else
            {
                //Error Message
                MessageBox.Show("Please type in number for family member2 age.");
            }

            //Get Phone Number
            if (double.TryParse(mem1PhoNumTextBox.Text, out double phoneNumber))
            {
                member2.PhoneNumber = phoneNumber;
            }
            else
            {
                //error message
                MessageBox.Show("Type in numbers for family memeber 2 phone number");
            }

        }

        private void addButton_Click(object sender, EventArgs e)
        {
            // New object
            Person people = new Person();
            Person fam1 = new Person();
            Person fam2 = new Person();

            //Get Data
            GetUserData(people);
            GetMem1Data(fam1);
            GetMem2Data(fam2);

            
            //Display Family info
            displayLabel.Text = (people.Name+" "+people.Address+" "+people.Age+" "
            +people.PhoneNumber+Environment.NewLine + Environment.NewLine + fam1.Name+ " " +fam1.Address+
            " "+ fam1.Age +" "+ fam1.PhoneNumber+Environment.NewLine+Environment.NewLine+ fam2.Name+
            " " + fam2.Address + " " + fam2.Age + " "+ fam2.PhoneNumber);

           

            
            

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close form
            this.Close();
        }
    }
}
