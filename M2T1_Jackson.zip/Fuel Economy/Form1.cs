﻿/**
* 2/05/2017
* CSC 153
* Byron Jackson, Jr.
* Get input from user and display results
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fuel_Economy
{
    public partial class fuelEconomy : Form
    {
        public fuelEconomy()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double miles;     //hold miles
            double gallons;   //hold gallons
            double mpg;       //hold MPG

            //Get miles driven and assign to vairable
            miles = double.Parse(milesTextBox.Text);

            //Get gallons and assign it to gallons variable
            gallons = double.Parse(gallonsTextBox.Text);

            //Calculate MPG
            mpg = miles / gallons;

            //Dislay MPG in mpgLabel control
            mpgLabel.Text = mpg.ToString();


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the forum
            this.Close();
        }

       
        

        }
    }

