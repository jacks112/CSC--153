﻿/*
 * 5/14/2018
 * CSC-153
 * Byron Jackson, Jr.
 * This program calculates sales with discount range
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

               

        


        private void submitButton_Click(object sender, EventArgs e)
        {
            //Declare vairables
            double discount = 0;
            double package = 99;
            double amount = 0;
            double subPrice = 0;
            double totalPrice = 0;

            //Get amount to purchase
            if (double.TryParse(textBox1.Text, out amount))
            {
                MessageBox.Show("You chose " + amount + " packages.");
            }
            else
            {
                //Error message
                MessageBox.Show("Please enter a number to purchase.");

            }

            //Get subtotal
            subPrice = package * amount;

            //Calculate discount
            if(amount < 10)
            {
                discount = 0;
            }
            else if(amount <= 19)
            {
                discount = .20 * subPrice;
            }
            else if(amount <= 49)
            {
                discount = .30 * subPrice;
            }
            else if(amount <= 99)
            {
                discount = .40 * subPrice;
            }
            else if(amount >= 100)
            {
                discount = .50 * subPrice;
            }

            //Get totalPrice with discount
            totalPrice = subPrice - discount;
            displyLabel.Text = "You saved "+ discount.ToString("c")+"."
            +"Your total today is " + totalPrice.ToString("c") + ".";
             


        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            //Close form
            this.Close();
        }
    }
}
