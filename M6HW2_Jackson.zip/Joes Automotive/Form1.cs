﻿/**
 * 04/20/2018
 * CSC 153
 * Byron Jackson, Jr.
 * This program makes a form for getting 
 * totals for automotive work
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Joes_Automotive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Declare variables
        double oilLubeCharge;
        double flushCharge;
        double miscCharge;
        double partsCharge;
        double labor;
        private const double tax = .06;
        double taxCharge;
        private void CalculateButton_Click(object sender, EventArgs e)
        {
            //Get the sum of Oil and Lube.
            if(oilChangeCheckBox.Checked)
            {
                oilLubeCharge = 26;
            }
            if (lubeJobCheckBox.Checked)
            {
                oilLubeCharge = 18 + oilLubeCharge;
            }

            //Get the sum of Misc.
            if (inspectionCheckBox.Checked)
            {
                miscCharge = 15;
            }
            if (replaceMufflerCheckBox.Checked)
            {
                miscCharge = 100 + miscCharge;
            }
            if (tiresRotationCheckBox.Checked)
            {
                miscCharge = 20 + miscCharge;
            }

            //Get the sum of Flush.
            if (radiatorFlushCheckBox.Checked)
            {
                flushCharge = 30;
            }
            if (transmissionFlushCheckBox.Checked)
            {
                flushCharge = 80 + flushCharge;
            }

            //Get parts cost
            partsCharge = double.Parse(partsTextBox.Text);

            //Get labor cost
            labor = double.Parse(laborTextBox.Text);

            //Get totals
            double serviceCharge = oilLubeCharge + miscCharge + flushCharge;
            taxCharge = (tax * partsCharge);
            double totalCharge = serviceCharge + labor + (partsCharge + taxCharge);


            //Send totals to Labels
            serviceAndLaborLabel.Text = (serviceCharge + labor).ToString("c");
            partsLabel.Text = partsCharge.ToString("c");
            taxOnPartsLabel.Text = taxCharge.ToString("c");
            totalFeesLabel.Text = totalCharge.ToString("c");
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            serviceAndLaborLabel.Text = "";
            partsLabel.Text = "";
            taxOnPartsLabel.Text = "";
            totalFeesLabel.Text = "";
            partsTextBox.Text = "";
            laborTextBox.Text = "";
             oilChangeCheckBox.Checked = false;
             lubeJobCheckBox.Checked = false;
            inspectionCheckBox.Checked = false;
            replaceMufflerCheckBox.Checked = false;
            tiresRotationCheckBox.Checked = false;
            radiatorFlushCheckBox.Checked = false;
            transmissionFlushCheckBox.Checked = false;
            
            

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close form
            this.Close();
        }
    }
}
