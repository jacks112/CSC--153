﻿/**
 * 3/20/2018
 * CSC 153
 * Byron Jackson,Jr.
 * Program Calculate population growth with While loop and increments
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
                             //declare varaibles
            double numOrganism = 0;           //hold number of organisms
            double dailyIncrease = 0;    //hold percent increase
            int numOfDays = 0;         //hold the number of days
            int count = 1;              // count varaible

                           //Get the values from the text boxes
            numOrganism = double.Parse(numberOfOrganismsBox.Text);
            dailyIncrease = double.Parse(averageIncreaseBox.Text);
            numOfDays = int.Parse(daysBox.Text);
            dailyIncrease = dailyIncrease / 100;

                         //calculate growth
            double growthRate = numOrganism * dailyIncrease;
            dailyGrowthBox.Items.Add("The daily growth for day 1 is " + numOrganism);
            while (++count <= numOfDays)
            {
                growthRate = numOrganism * dailyIncrease;
                numOrganism = growthRate + numOrganism;
                        //Display growth rate in listbox
                dailyGrowthBox.Items.Add("The daily growth for day " + count + " is " + numOrganism);
                
            }

        }
    }
}
