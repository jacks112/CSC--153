﻿/**
 * 5/07/2018
 * CSC 153
 * Byron Jackson, Jr.
 * This program creates a pet class and gets the propeties
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pet_Class
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        List<Pet> petList = new List<Pet>();

        //Get Pet data
        private void GetPetData(Pet creature)
        {
            //Get Pet Name
            creature.Name = nameTextBox.Text;

            //Get Pet type
            creature.Type = typeTextBox.Text;

            //Get Pet age
            creature.Age = ageTextBox.Text;

        }

        private void addPetButton_Click(object sender, EventArgs e)
        {
            //Create a Pet object
            Pet animal = new Pet();

            //Get Pet Data
            GetPetData(animal);

            //Add Pet object to list
            petList.Add(animal);

            //Add entry to petListBox
            petListBox.Items.Add(animal.Name + " " + animal.Type + " " + animal.Age);

            //Clear the text box controls
            nameTextBox.Clear();
            typeTextBox.Clear();
            ageTextBox.Clear();

            //Reset focus
            nameTextBox.Focus();

                
            
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close form
            this.Close();
        }
    }
}
