﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pet_Class
{
    class Pet
    {
        //Variables to hold pet properties
        string name;
        string type;
        string age;

        //Name property
        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        //Type property
        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        //Age property
        public string Age
        {
            get { return age; }
            set { age = value; }
        }

    }
}
