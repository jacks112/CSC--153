﻿/*
 * 5/07/2018
 * CSC 153
 * Byron Jackson, Jr.
 * Program gets car property thru class 
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Car_Class_Program
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Speed variable
        int speed;

        //Get the Car Data
        private void GetCarData(Car car)
        {
            //Get year of car
            car.Year = yearTextBox.Text;

            //Get make of car
            car.Make = makeTextBox.Text;

            //Get speed
            car.Speed = speed; 
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        { 
            //Acceleration for MPH
            speed += 5;
            speedLabel.Text = ("" + speed);
            
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            //Brake for MPH
            speed -= 5;
            speedLabel.Text = ("" + speed);

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close form
            this.Close();
        }
    }
}
