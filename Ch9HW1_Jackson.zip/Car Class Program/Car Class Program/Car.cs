﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Class_Program
{
    class Car
    {
        //Declare fields
        string _year;
        string _make;
        int _speed;

        //Constructor
        public Car(string year, string make)
        {
            _year = year;
            _make = make;
            _speed = 0;
           
        }

        //Year property
        public string Year
        {
            get { return _year; }
            set { _year = value; }
        }

        //Make property
        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }

        //Speed property
        
        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }   
        

        

            

            
        
        

    }
}
