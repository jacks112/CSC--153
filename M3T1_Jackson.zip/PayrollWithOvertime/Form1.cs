﻿/**
 * 2/21/2018
 * CSC153
 * Byron Jackson
 * This program calculate pay rate plus overtime pay
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PayrollWithOvertime
{
    public partial class PayrollWithOvertime : Form
    {
        public PayrollWithOvertime()
        {
            InitializeComponent();
        }

        private void calulateButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Name constants
                const decimal Base_Hours = 40m;
                const decimal OT_Multiplier = 1.5m;

                //Local variables
                decimal hoursWorked, hourlypayRate, basePay, overtimeHours, overtimePay, grossPay;

                //Get hours worked and pay rate
                hoursWorked = decimal.Parse(hoursWorkedTextBox.Text);
                hourlypayRate = decimal.Parse(hourlyPayTextBox.Text);

                //Determine gross pay
                if(hoursWorked > Base_Hours)
                    {
                    //Calculate base pay with out overtime
                    basePay = hourlypayRate * Base_Hours;

                    //Calculate number of overtime hours
                    overtimeHours = hoursWorked - Base_Hours;

                    //Calculate overtime pay
                    overtimePay = overtimeHours * hourlypayRate * OT_Multiplier;

                    //Calculate the gross pay
                    grossPay = basePay + overtimePay;
                    }
                else
                {
                    //Calculate the gross
                    grossPay = hoursWorked * hourlypayRate;
                }

                //Display the gross pay
                grossPayTextBox.Text = grossPay.ToString("c");
            }

            catch (Exception ex)
            {
                //Display an error message
                MessageBox.Show(ex.Message);
            }

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clear form data
            hoursWorkedTextBox.Text = "";
            hourlyPayTextBox.Text = "";
            grossPayTextBox.Text = "";

            //Reset the Focus
            hoursWorkedTextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close application
            this.Close();
        }
    }
}
