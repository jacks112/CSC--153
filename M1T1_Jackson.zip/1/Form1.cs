﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* Jan.25,2018
* CSC 153
* Byron Jackson, Jr.
* Click evennt display meassage
*/
namespace _1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void messgeButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello World");

        }
    }
}
