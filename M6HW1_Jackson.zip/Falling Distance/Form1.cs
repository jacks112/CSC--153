﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        // Create constant vairble G for acceleration on gravity
        private const double G = 9.8;

        //Create variable to hold Distance in meters
        double Distance;

        //Method to get time value and calculate Distance
        public void Falling_Distance()
        {
            //Variable to hold Value for Time
            double T;

                  //Get value of varaible T from user
            if (double.TryParse(timeTextBox.Text, out T))
            {
             
                if(T > 0)
                {
                    // Calculate Distance
                    Distance = .5 * G * (Math.Pow( T, 2));

                    //Display Distance for user in displayLabel
                    displayLabel.Text = ("The Distance the object fell is " 
                        + Distance + " meters");
                }
                else
                {
                    displayLabel.Text = ("Please type a number that is larger than 0");
                }
            }

            else
            {
                MessageBox.Show("Please type a number(ex. 1, 2, 3, ..etc)");

            }
        }

        private void calculateDistanceButton_Click(object sender, EventArgs e)
        {

            
            Falling_Distance();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close program
            this.Close();
        }
    }
}
