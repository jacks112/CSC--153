﻿/**
 * 04/25/2018
 * CSC 153
 * Byron Jackson, Jr.
 * David Howland
 * Matthew Hunter
 * Program is a game of rock, paper, scissors between user and computer
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rock__Paper__Scissors_Game
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        
        int rock = 1;
        int paper = 2;
        int scissors = 3;
        int ComPlayer = 0;
        int cC = 0;
        
        //Method to get Computer's choice.
        private int ComChoice(int x)
        {
            comScissorsPictureBox.Visible = false;
            comRockPictureBox.Visible = false;
            comPaperPictureBox.Visible = false;

            //Generate random number 1-3 to get computer choice
            Random rand = new Random();
            x = rand.Next(3) + 1;

            if (x == rock)
            {
                comRockPictureBox.Visible = true;
            }
            else if(x == paper)
            {
                comPaperPictureBox.Visible = true;
            }
            else if(x == scissors)
            {
                comScissorsPictureBox.Visible = true;
            }

            return x;

        }

       private void rockPictureBox_Click(object sender, EventArgs e)
       {
      
            //player1 = rock;
               
            //Get Computer choice
               ComPlayer = ComChoice(cC);

            //Get results 
            if (ComPlayer == paper)
            {
                
                

                resultsLabel.Text = "Paper beats rock. Computer wins.";

            }
            else if (ComPlayer == scissors)
            {
                
                resultsLabel.Text = "Rock beats scissors. Player wins!";
            }
            else if(ComPlayer == rock)
            {
                
                resultsLabel.Text = "You both chose rock. Nobody wins.";
            }

          
        }


            

            private void paperPictureBox_Click(object sender, EventArgs e)
            {
                //player1 = paper

                //Get Computer choice
                ComPlayer = ComChoice(cC);
                
                //Get results
                if(ComPlayer == rock)
                {
                    
                    resultsLabel.Text = "Paper beats rock. Player wins!";
                }
                else if(ComPlayer == 3)
                {
                    resultsLabel.Text = "Scissors beat paper. Computer wins.";
                }
                else if(ComPlayer == 2)
                {
                resultsLabel.Text = "You both chose paper. Nobody wins.";
                }
            }

            private void scissorsPictureBox_Click(object sender, EventArgs e)
            {
                //player1 = scissors

                //Get Computer choice.
                ComPlayer = ComChoice(cC);
                  
                 //Get results
                if(ComPlayer == 1)
                {
                    resultsLabel.Text = "Rock beats scissors. Computer wins.";
                }
                 else if(ComPlayer == 2)
                {
                    resultsLabel.Text = "Scissors beat paper. Player wins!";
                }
                else if(ComPlayer == 3)
                {
                resultsLabel.Text = "You both chose scissors. Nobody wins.";
                    
                }
           
       
            }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //This closes the form
            this.Close();
        }
    }
}
