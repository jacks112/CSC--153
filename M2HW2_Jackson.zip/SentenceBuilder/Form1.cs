﻿/**
 * 2/18/2018
 * CSC 153
 * Byron Jackson, Jr.
 * Combines words to make a sentence
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SentenceBuilder
{
    public partial class SentenceBuilder : Form
    {
        //Declare variable
        private string sen = ("");

        public SentenceBuilder()
        {
            InitializeComponent();
        }

        
                   // send " " to label1 text box
        private void button2_Click(object sender, EventArgs e)
        {
            sen += "you";
            label1.Text = sen;

        }

        private void dogB_Click(object sender, EventArgs e)
        {
            sen += "dog";
            label1.Text = sen;
        }

        private void catB_Click(object sender, EventArgs e)
        {
            sen += "cat";
            label1.Text = sen;
        }

        private void TheB_Click(object sender, EventArgs e)
        {
            sen += "The";
            label1.Text = sen;
        }

        private void theBut_Click(object sender, EventArgs e)
        {
            sen += "the";
            label1.Text = sen;
        }

        private void manB_Click(object sender, EventArgs e)
        {
            sen += "man";
            label1.Text = sen;

        }

        private void womanB_Click(object sender, EventArgs e)
        {
            sen += "woman";
            label1.Text = sen;

        }

        private void carB_Click(object sender, EventArgs e)
        {
            sen += "car";
            label1.Text = sen;

        }

        private void bikeB_Click(object sender, EventArgs e)
        {
            sen += "bike";
            label1.Text = sen;

        }

        private void bigB_Click(object sender, EventArgs e)
        {
            sen += "big";
            label1.Text = sen;

        }

        private void droveB_Click(object sender, EventArgs e)
        {
            sen += "drove";
            label1.Text = sen;

        }

        private void smallB_Click(object sender, EventArgs e)
        {
            sen += "small";
            label1.Text = sen;

        }

        private void ranB_Click(object sender, EventArgs e)
        {
            sen += "ran";
            label1.Text = sen;

        }

        private void canB_Click(object sender, EventArgs e)
        {
            sen += "can";
            label1.Text = sen;

        }

        private void jumpB_Click(object sender, EventArgs e)
        {
            sen += "jump";
            label1.Text = sen;

        }

        private void rodeB_Click(object sender, EventArgs e)
        {
            sen += "rode";
            label1.Text = sen;

        }

        private void overB_Click(object sender, EventArgs e)
        {
            sen += "over";
            label1.Text = sen;

        }

        private void fastB_Click(object sender, EventArgs e)
        {
            sen += "fast";
            label1.Text = sen;

        }

        private void spaceBar_Click(object sender, EventArgs e)
        {
            //Insert space
            sen += " ";
            label1.Text = sen;

        }

        private void periodB_Click(object sender, EventArgs e)
        {
            sen += ".";
            label1.Text = sen;
        }

        private void questionB_Click(object sender, EventArgs e)
        {
            sen += "?";
            label1.Text = sen;
        }

        private void aButton_Click(object sender, EventArgs e)
        {
            sen += "a";
            label1.Text = sen;
        }

        private void AB_Click(object sender, EventArgs e)
        {
            sen += "A";
            label1.Text = sen;
        }

        private void clearB_Click(object sender, EventArgs e)
        {
            //clear label1 text box
            sen = "";
            label1.Text = sen;
        }

        private void exitB_Click(object sender, EventArgs e)
        {
            //close form
            this.Close();
        }
    }
}
