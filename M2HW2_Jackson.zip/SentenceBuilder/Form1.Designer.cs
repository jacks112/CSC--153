﻿namespace SentenceBuilder
{
    partial class SentenceBuilder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AB = new System.Windows.Forms.Button();
            this.youB = new System.Windows.Forms.Button();
            this.dogB = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.catB = new System.Windows.Forms.Button();
            this.TheB = new System.Windows.Forms.Button();
            this.theBut = new System.Windows.Forms.Button();
            this.manB = new System.Windows.Forms.Button();
            this.womanB = new System.Windows.Forms.Button();
            this.carB = new System.Windows.Forms.Button();
            this.bikeB = new System.Windows.Forms.Button();
            this.bigB = new System.Windows.Forms.Button();
            this.smallB = new System.Windows.Forms.Button();
            this.ranB = new System.Windows.Forms.Button();
            this.canB = new System.Windows.Forms.Button();
            this.jumpB = new System.Windows.Forms.Button();
            this.droveB = new System.Windows.Forms.Button();
            this.rodeB = new System.Windows.Forms.Button();
            this.overB = new System.Windows.Forms.Button();
            this.fastB = new System.Windows.Forms.Button();
            this.spaceBar = new System.Windows.Forms.Button();
            this.periodB = new System.Windows.Forms.Button();
            this.questionB = new System.Windows.Forms.Button();
            this.aButton = new System.Windows.Forms.Button();
            this.clearB = new System.Windows.Forms.Button();
            this.exitB = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AB
            // 
            this.AB.Location = new System.Drawing.Point(32, 31);
            this.AB.Name = "AB";
            this.AB.Size = new System.Drawing.Size(75, 23);
            this.AB.TabIndex = 0;
            this.AB.Text = "A";
            this.AB.UseVisualStyleBackColor = true;
            this.AB.Click += new System.EventHandler(this.AB_Click);
            // 
            // youB
            // 
            this.youB.Location = new System.Drawing.Point(141, 31);
            this.youB.Name = "youB";
            this.youB.Size = new System.Drawing.Size(75, 23);
            this.youB.TabIndex = 1;
            this.youB.Text = "you";
            this.youB.UseVisualStyleBackColor = true;
            this.youB.Click += new System.EventHandler(this.button2_Click);
            // 
            // dogB
            // 
            this.dogB.Location = new System.Drawing.Point(247, 30);
            this.dogB.Name = "dogB";
            this.dogB.Size = new System.Drawing.Size(75, 23);
            this.dogB.TabIndex = 2;
            this.dogB.Text = "dog";
            this.dogB.UseVisualStyleBackColor = true;
            this.dogB.Click += new System.EventHandler(this.dogB_Click);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(42, 274);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(621, 40);
            this.label1.TabIndex = 3;
            // 
            // catB
            // 
            this.catB.Location = new System.Drawing.Point(349, 31);
            this.catB.Name = "catB";
            this.catB.Size = new System.Drawing.Size(75, 23);
            this.catB.TabIndex = 4;
            this.catB.Text = "cat";
            this.catB.UseVisualStyleBackColor = true;
            this.catB.Click += new System.EventHandler(this.catB_Click);
            // 
            // TheB
            // 
            this.TheB.Location = new System.Drawing.Point(469, 30);
            this.TheB.Name = "TheB";
            this.TheB.Size = new System.Drawing.Size(75, 23);
            this.TheB.TabIndex = 5;
            this.TheB.Text = "The";
            this.TheB.UseVisualStyleBackColor = true;
            this.TheB.Click += new System.EventHandler(this.TheB_Click);
            // 
            // theBut
            // 
            this.theBut.Location = new System.Drawing.Point(578, 30);
            this.theBut.Name = "theBut";
            this.theBut.Size = new System.Drawing.Size(75, 23);
            this.theBut.TabIndex = 6;
            this.theBut.Text = "the";
            this.theBut.UseVisualStyleBackColor = true;
            this.theBut.Click += new System.EventHandler(this.theBut_Click);
            // 
            // manB
            // 
            this.manB.Location = new System.Drawing.Point(106, 88);
            this.manB.Name = "manB";
            this.manB.Size = new System.Drawing.Size(75, 23);
            this.manB.TabIndex = 7;
            this.manB.Text = "man";
            this.manB.UseVisualStyleBackColor = true;
            this.manB.Click += new System.EventHandler(this.manB_Click);
            // 
            // womanB
            // 
            this.womanB.Location = new System.Drawing.Point(295, 87);
            this.womanB.Name = "womanB";
            this.womanB.Size = new System.Drawing.Size(75, 23);
            this.womanB.TabIndex = 8;
            this.womanB.Text = "woman";
            this.womanB.UseVisualStyleBackColor = true;
            this.womanB.Click += new System.EventHandler(this.womanB_Click);
            // 
            // carB
            // 
            this.carB.Location = new System.Drawing.Point(393, 87);
            this.carB.Name = "carB";
            this.carB.Size = new System.Drawing.Size(75, 23);
            this.carB.TabIndex = 9;
            this.carB.Text = "car";
            this.carB.UseVisualStyleBackColor = true;
            this.carB.Click += new System.EventHandler(this.carB_Click);
            // 
            // bikeB
            // 
            this.bikeB.Location = new System.Drawing.Point(508, 87);
            this.bikeB.Name = "bikeB";
            this.bikeB.Size = new System.Drawing.Size(75, 23);
            this.bikeB.TabIndex = 10;
            this.bikeB.Text = "bike";
            this.bikeB.UseVisualStyleBackColor = true;
            this.bikeB.Click += new System.EventHandler(this.bikeB_Click);
            // 
            // bigB
            // 
            this.bigB.Location = new System.Drawing.Point(607, 88);
            this.bigB.Name = "bigB";
            this.bigB.Size = new System.Drawing.Size(75, 23);
            this.bigB.TabIndex = 11;
            this.bigB.Text = "big";
            this.bigB.UseVisualStyleBackColor = true;
            this.bigB.Click += new System.EventHandler(this.bigB_Click);
            // 
            // smallB
            // 
            this.smallB.Location = new System.Drawing.Point(141, 153);
            this.smallB.Name = "smallB";
            this.smallB.Size = new System.Drawing.Size(75, 23);
            this.smallB.TabIndex = 12;
            this.smallB.Text = "small";
            this.smallB.UseVisualStyleBackColor = true;
            this.smallB.Click += new System.EventHandler(this.smallB_Click);
            // 
            // ranB
            // 
            this.ranB.Location = new System.Drawing.Point(198, 87);
            this.ranB.Name = "ranB";
            this.ranB.Size = new System.Drawing.Size(75, 23);
            this.ranB.TabIndex = 13;
            this.ranB.Text = "ran";
            this.ranB.UseVisualStyleBackColor = true;
            this.ranB.Click += new System.EventHandler(this.ranB_Click);
            // 
            // canB
            // 
            this.canB.Location = new System.Drawing.Point(349, 153);
            this.canB.Name = "canB";
            this.canB.Size = new System.Drawing.Size(75, 23);
            this.canB.TabIndex = 14;
            this.canB.Text = "can";
            this.canB.UseVisualStyleBackColor = true;
            this.canB.Click += new System.EventHandler(this.canB_Click);
            // 
            // jumpB
            // 
            this.jumpB.Location = new System.Drawing.Point(469, 153);
            this.jumpB.Name = "jumpB";
            this.jumpB.Size = new System.Drawing.Size(75, 23);
            this.jumpB.TabIndex = 15;
            this.jumpB.Text = "jump";
            this.jumpB.UseVisualStyleBackColor = true;
            this.jumpB.Click += new System.EventHandler(this.jumpB_Click);
            // 
            // droveB
            // 
            this.droveB.Location = new System.Drawing.Point(32, 153);
            this.droveB.Name = "droveB";
            this.droveB.Size = new System.Drawing.Size(75, 23);
            this.droveB.TabIndex = 16;
            this.droveB.Text = "drove";
            this.droveB.UseVisualStyleBackColor = true;
            this.droveB.Click += new System.EventHandler(this.droveB_Click);
            // 
            // rodeB
            // 
            this.rodeB.Location = new System.Drawing.Point(578, 153);
            this.rodeB.Name = "rodeB";
            this.rodeB.Size = new System.Drawing.Size(75, 23);
            this.rodeB.TabIndex = 17;
            this.rodeB.Text = "rode";
            this.rodeB.UseVisualStyleBackColor = true;
            this.rodeB.Click += new System.EventHandler(this.rodeB_Click);
            // 
            // overB
            // 
            this.overB.Location = new System.Drawing.Point(247, 153);
            this.overB.Name = "overB";
            this.overB.Size = new System.Drawing.Size(75, 23);
            this.overB.TabIndex = 18;
            this.overB.Text = "over";
            this.overB.UseVisualStyleBackColor = true;
            this.overB.Click += new System.EventHandler(this.overB_Click);
            // 
            // fastB
            // 
            this.fastB.Location = new System.Drawing.Point(12, 201);
            this.fastB.Name = "fastB";
            this.fastB.Size = new System.Drawing.Size(75, 23);
            this.fastB.TabIndex = 19;
            this.fastB.Text = "fast";
            this.fastB.UseVisualStyleBackColor = true;
            this.fastB.Click += new System.EventHandler(this.fastB_Click);
            // 
            // spaceBar
            // 
            this.spaceBar.Location = new System.Drawing.Point(141, 201);
            this.spaceBar.Name = "spaceBar";
            this.spaceBar.Size = new System.Drawing.Size(191, 51);
            this.spaceBar.TabIndex = 20;
            this.spaceBar.Text = "Space";
            this.spaceBar.UseVisualStyleBackColor = true;
            this.spaceBar.Click += new System.EventHandler(this.spaceBar_Click);
            // 
            // periodB
            // 
            this.periodB.Location = new System.Drawing.Point(349, 201);
            this.periodB.Name = "periodB";
            this.periodB.Size = new System.Drawing.Size(75, 51);
            this.periodB.TabIndex = 21;
            this.periodB.Text = ".";
            this.periodB.UseVisualStyleBackColor = true;
            this.periodB.Click += new System.EventHandler(this.periodB_Click);
            // 
            // questionB
            // 
            this.questionB.Location = new System.Drawing.Point(469, 201);
            this.questionB.Name = "questionB";
            this.questionB.Size = new System.Drawing.Size(75, 51);
            this.questionB.TabIndex = 22;
            this.questionB.Text = "?";
            this.questionB.UseVisualStyleBackColor = true;
            this.questionB.Click += new System.EventHandler(this.questionB_Click);
            // 
            // aButton
            // 
            this.aButton.Location = new System.Drawing.Point(12, 87);
            this.aButton.Name = "aButton";
            this.aButton.Size = new System.Drawing.Size(75, 23);
            this.aButton.TabIndex = 23;
            this.aButton.Text = "a";
            this.aButton.UseVisualStyleBackColor = true;
            this.aButton.Click += new System.EventHandler(this.aButton_Click);
            // 
            // clearB
            // 
            this.clearB.Location = new System.Drawing.Point(140, 330);
            this.clearB.Name = "clearB";
            this.clearB.Size = new System.Drawing.Size(75, 23);
            this.clearB.TabIndex = 24;
            this.clearB.Text = "Clear";
            this.clearB.UseVisualStyleBackColor = true;
            this.clearB.Click += new System.EventHandler(this.clearB_Click);
            // 
            // exitB
            // 
            this.exitB.Location = new System.Drawing.Point(469, 329);
            this.exitB.Name = "exitB";
            this.exitB.Size = new System.Drawing.Size(75, 23);
            this.exitB.TabIndex = 25;
            this.exitB.Text = "Exit";
            this.exitB.UseVisualStyleBackColor = true;
            this.exitB.Click += new System.EventHandler(this.exitB_Click);
            // 
            // SentenceBuilder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(714, 365);
            this.Controls.Add(this.exitB);
            this.Controls.Add(this.clearB);
            this.Controls.Add(this.aButton);
            this.Controls.Add(this.questionB);
            this.Controls.Add(this.periodB);
            this.Controls.Add(this.spaceBar);
            this.Controls.Add(this.fastB);
            this.Controls.Add(this.overB);
            this.Controls.Add(this.rodeB);
            this.Controls.Add(this.droveB);
            this.Controls.Add(this.jumpB);
            this.Controls.Add(this.canB);
            this.Controls.Add(this.ranB);
            this.Controls.Add(this.smallB);
            this.Controls.Add(this.bigB);
            this.Controls.Add(this.bikeB);
            this.Controls.Add(this.carB);
            this.Controls.Add(this.womanB);
            this.Controls.Add(this.manB);
            this.Controls.Add(this.theBut);
            this.Controls.Add(this.TheB);
            this.Controls.Add(this.catB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dogB);
            this.Controls.Add(this.youB);
            this.Controls.Add(this.AB);
            this.Name = "SentenceBuilder";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button AB;
        private System.Windows.Forms.Button youB;
        private System.Windows.Forms.Button dogB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button catB;
        private System.Windows.Forms.Button TheB;
        private System.Windows.Forms.Button theBut;
        private System.Windows.Forms.Button manB;
        private System.Windows.Forms.Button womanB;
        private System.Windows.Forms.Button carB;
        private System.Windows.Forms.Button bikeB;
        private System.Windows.Forms.Button bigB;
        private System.Windows.Forms.Button smallB;
        private System.Windows.Forms.Button ranB;
        private System.Windows.Forms.Button canB;
        private System.Windows.Forms.Button jumpB;
        private System.Windows.Forms.Button droveB;
        private System.Windows.Forms.Button rodeB;
        private System.Windows.Forms.Button overB;
        private System.Windows.Forms.Button fastB;
        private System.Windows.Forms.Button spaceBar;
        private System.Windows.Forms.Button periodB;
        private System.Windows.Forms.Button questionB;
        private System.Windows.Forms.Button aButton;
        private System.Windows.Forms.Button clearB;
        private System.Windows.Forms.Button exitB;
    }
}

