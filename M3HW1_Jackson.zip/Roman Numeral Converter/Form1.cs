﻿/*
 * 2/23/2018
 * CSC 153
 * Byron Jackson
 * This program convert Number to Roman Numeral with if else statements 
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roman_Numeral_Converter
{
    public partial class RomanNumeralConverter : Form
    {
        public RomanNumeralConverter()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            //Declare vairable
            int number; 

            //Get number in range of 1 to 10 and convert to interger.

            if(int.TryParse(textBox1.Text, out number))
            {
                if (number >= 1 && number <= 10)
                {
                    //Continue to process input
                }
                else
                {
                    MessageBox.Show("Number selection must be in the range of 1 thru 10.");
                }
                
            }
            else
            {
                MessageBox.Show("Must type a number.");
            }
                //If statment take int saved in number vairable and give the roman numeral

                if (number == 1)
                {
                   MessageBox.Show("        I");
                }
                else if(number == 2)
                {
                   MessageBox.Show("        II");
                }
                else if (number == 3)
                {
                   MessageBox.Show("        III");
                }
                else if (number == 4)
                {
                   MessageBox.Show("        IV");
                }
                else if (number == 5)
                {
                   MessageBox.Show("        V");
                }
                else if (number == 6)
                {
                   MessageBox.Show("        VI");
                }
                else if (number == 7)
                {
                   MessageBox.Show("        VII");
                }
                else if (number == 8)
                {
                   MessageBox.Show("        VIII");
                }
                else if (number == 9)
                {
                   MessageBox.Show("        IX");
                }
                else if (number == 10)
                {
                   MessageBox.Show("        X");
                }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close Form
            this.Close();
        }
    }
}
